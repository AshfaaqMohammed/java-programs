package com.MultiThreading.Executers;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class FixedThreadPool {
    public static void main(String[] args) {
        Thread task1 = new Thread(()->{
            System.out.println(Thread.currentThread().getName() + " started");
            for(int i=0;i<5;i++){
                try{
                    System.out.println("num = " + i);
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

            }
        },"ashTask");

        Thread task2 = new Thread(()->{
            System.out.println(Thread.currentThread().getName() + " started");
            for(int i=5;i<10;i++){
                try{
                    System.out.println("num = " + i);
                    Thread.sleep(1000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

            }
        },"adilTask");


        ExecutorService executorService = Executors.newFixedThreadPool(2);
        for (int i=0;i<2;i++){
            executorService.execute(task1);
            executorService.execute(task2);
        }
        executorService.shutdown();
    }
}

package com.MultiThreading.Executers;

/*
    CachedThreadPool will creates as many threads as required for the submitted task.
        1. if a thread is available for executing the task, it will use the thread to execute
        2. if no thread is available for executing the task, then CachedThreadPool will create a new thread to execute the task.
        3. there is no concept called threadqueue
 */

public class CachedThreadPool {
}
